#!/usr/bin/perl -w
use strict;
#use Lingua::EN::Tagger;
use Data::Dumper;
use File::Slurp;
#use Lingua::EN::NamedEntity;
use Lingua::EN::Sentence qw(get_sentences);

my $infile="raw_files.txt";
my @lines=read_file($infile);

#print @lines;

my $line;
my $fullfilename;
my $text;
my $sentences;
my $sentence;
my @temp=();
my $scount=0;
my $t;


#print "Start\n";
my $path="./data/muc34/TASK/CORPORA/raw_files/";

foreach my $line (@lines){
	#print "****\n";
	chomp($line);
	#print $line;
	$fullfilename=$path.$line;
	#print $fullfilename;
	$text=read_file($fullfilename); #gets text of file
	#print Dumper($text);
	#split to sentences
	$sentences=get_sentences($text);
	#print Dumper(@$sentences);
	
	#print Dumper(@entities);
	#print "****\n";
	#process sentence array
	foreach $sentence (@$sentences) {
		$scount++;
		$sentence=~ s/\n+/ /g;
		#print $line."|".$sentence;
		#@entities=extract_entities($sentence);
		#print Dumper(@entities);
		#foreach $ent (@entities){
		#	print $ent;
		#}
		push @temp,join("|",($line,$scount,$sentence));
	}
	$scount=0;
}

#print Dumper(@temp);
foreach $t (@temp){
	print $t."\n";
}
