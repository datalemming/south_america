#!/usr/bin/env python
# coding: utf-8
import textacy
#import textacy.keyterms
import csv

corpus=textacy.Corpus.load('s_american_corpus.pkl')
print(corpus)

svos_list=[]

for doc in corpus:
    #doctext=str(doc.text)
    #doctext=doctext.replace('\n',' ')
    docid=(str(doc[:5]))
    svos=textacy.extract.subject_verb_object_triples(doc)
    for t in svos:
        print(docid, t, type(t))
        svos_list.append((docid,t))

with open("svos.csv", 'w', newline='')as csvfile:
    fwriter=csv.writer(csvfile, quoting=csv.QUOTE_MINIMAL, delimiter='|')
    for o in svos_list:
        fwriter.writerow([o[0],o[1]])

