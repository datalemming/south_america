CREATE TABLE "logs" (
    `logid` text,
    `logcontent` text,
    PRIMARY KEY(logid)
);
