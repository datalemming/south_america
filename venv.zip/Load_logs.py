#!/usr/bin/env python
# coding: utf-8

import textacy
corpus=textacy.Corpus.load("s_american_corpus.pkl")
print(corpus)

print("Initialise list")
lst=[]

for doc in corpus:
    doctext=str(doc.text)
    doctext=doctext.replace('\n',' ')
    docid=(str(doc[:5]))
    temp=(docid,doctext)
    lst.append(temp)
print(lst)
print('''**************************
          database load
          **********************''')
import sqlite3
conn=sqlite3.connect("south_america.db")
c=conn.cursor()
print(c)
c.executemany('INSERT INTO logs VALUES (?,?)',lst)
    
conn.commit()
conn.close()


