#!/usr/bin/env python
# coding: utf-8
import textacy
import textacy.keyterms
import csv

corpus=textacy.Corpus.load('s_american_corpus.pkl')
print(corpus)

output_nes=[]



for doc in corpus:
    #doctext=str(doc.text)
    #doctext=doctext.replace('\n',' ')
    docid=(str(doc[:5]))
    ne_list=textacy.extract.named_entities(doc, include_types=["PERSON","GPE","LOC"], drop_determiners=True)
    for ne in ne_list:
        print(docid, ne, ne.label_)
        output_nes.append((docid,ne, ne.label_))
     
with open("nes.csv", 'w', newline='')as csvfile:
    newriter=csv.writer(csvfile, quoting=csv.QUOTE_MINIMAL)
    for o in output_nes:
        newriter.writerow([o[0],o[1], o[2]])

