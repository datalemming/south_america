#!/usr/bin/env python
# coding: utf-8
import textacy
import textacy.keyterms
import csv

corpus=textacy.Corpus.load('s_american_corpus.pkl')
print(corpus)

output=[]
output_ss=[]

for doc in corpus:
    #doctext=str(doc.text)
    #doctext=doctext.replace('\n',' ')
    docid=(str(doc[:5]))
    kts=textacy.keyterms.sgrank(doc,normalize='lemma', window_width=30, n_keyterms=10)
    for kt in kts:
        print(docid, kt[0], type(kt[0]))
        output.append([docid,kt[0]])
        formats=textacy.extract.semistructured_statements(doc,kt[0])
        for f in formats:
            print(docid, kt[0],f)
            output_ss.append((docid,kt[0],f))
with open("key_terms.csv", 'w', newline='')as csvfile:
    ktwriter=csv.writer(csvfile, quoting=csv.QUOTE_MINIMAL)
    for o in output:
        ktwriter.writerow([o[0],o[1]])
with open("key_term_statements.csv","w", newline='') as csvfile2:
    ktwriter=csv.writer(csvfile2, quoting=csv.QUOTE_MINIMAL, delimiter='|')
    for o in output_ss:
        ktwriter.writerow([o[0],o[1], o[2]])
    
