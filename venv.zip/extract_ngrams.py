#!/usr/bin/env python
# coding: utf-8
import textacy
#import textacy.keyterms
import csv

corpus=textacy.Corpus.load('s_american_corpus.pkl')
print(corpus)

output_ncs=[]



for doc in corpus:
    #doctext=str(doc.text)
    #doctext=doctext.replace('\n',' ')
    docid=(str(doc[:5]))
    nc_list=textacy.extract.ngrams(doc,5,filter_stops=True, filter_punct=True)
    for nc in nc_list:
        print(docid, nc)
        #output_ncs.append((docid,n,c))
     
'''
with open("ncs.csv", 'w', newline='')as csvfile:
    ncwriter=csv.writer(csvfile, quoting=csv.QUOTE_MINIMAL)
    for o in output_ncs:
        ncwriter.writerow([o[0],o[1]])

'''
