#!/usr/bin/env python
# coding: utf-8
import textacy
import textacy.keyterms
import csv

corpus=textacy.Corpus.load('s_american_corpus.pkl')
print(corpus)

output_nps=[]
output_ss=[]

pattern=textacy.constants.POS_REGEX_PATTERNS['en']['PP']
print(pattern)

for doc in corpus:
    #doctext=str(doc.text)
    #doctext=doctext.replace('\n',' ')
    docid=(str(doc[:5]))
    np_list=textacy.extract.pos_regex_matches(doc, pattern)
    for np in np_list:
        print(docid, np)
        output_nps.append((docid,np))
        formats=textacy.extract.semistructured_statements(doc,np.text)
        for f in formats:
            print(docid, np.text, f)
            output_ss.append((docid, np.text, f))
        
        
       
with open("pps.csv", 'w', newline='')as csvfile:
    npwriter=csv.writer(csvfile, quoting=csv.QUOTE_MINIMAL)
    for o in output_nps:
        npwriter.writerow([o[0],o[1]])

with open("structure_statements_pps.csv", 'w', newline='')as csvfile:
    sswriter=csv.writer(csvfile, delimiter='|', quoting=csv.QUOTE_MINIMAL)
    for o in output_ss:
        sswriter.writerow([o[0],o[1], o[2]])

