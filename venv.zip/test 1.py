#!/usr/bin/env python
# coding: utf-8

import spacy
nlp=spacy.load('en')
import csv

with open('../sentence_data.csv', newline='') as csvfile:
    csvreader=csv.reader(csvfile, delimiter='|')
    #i=0
    for line in csvreader:
        print("Sentence")
        print(line)
        #i=i+1
        #if i>10:
        #    break
        doc=nlp(line[2])
        print("Entities")
        for ent in doc.ents:
            print(ent.text, ent.label_)
        print("Chunks")
        for chunk in doc.noun_chunks:
            print(chunk.text)
        print("")
        

